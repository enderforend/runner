var link = {
	'PointJS.' : '<a style="color: #FFF500;" href="#pointjs">PointJS</a>.',
	'.system.' : '.<a style="color: #4AFF00;" href="#PointJS.system">system</a>.',
	'.vector.' : '.<a style="color: #007EFF;" href="#PointJS.vector">vector</a>.',
	'.math.' : '.<a style="color: #9DCACF;" href="#PointJS.math">math</a>.',
	'.keyControl.' : '.<a style="color: #FFD281;" href="#PointJS.keyControl">keyControl</a>.',
	'.mouseControl.' : '.<a style="color: #FFD281;" href="#PointJS.mouseControl">mouseControl</a>.',
	'.touchControl.' : '.<a style="color: #FFD281;" href="#PointJS.touchControl">touchControl</a>.',
	'.colors.' : '.<a style="color: #FFA1CC;" href="#PointJS.colors">colors</a>.',
	'.OOP.' : '.<a style="color: #FCFF8E;" href="#PointJS.OOP">OOP</a>.',
	'.game.' : '.<a style="color: #8FFF94;" href="#PointJS.game">game</a>.',
	'.brush.' : '.<a style="color: #D4BAFF;" href="#PointJS.brush">brush</a>.',
	'.tiles.' : '.<a style="color: #D4BAFF;" href="#PointJS.tiles">tiles</a>.',
	'.audio.' : '.<a style="color: #9C7CD1;" href="#PointJS.audio">audio</a>.',



	'.size(' : '.<a style="color: #FFD36B;" href="#PointJS.vector.size">size</a>(',
	'.point(' : '.<a style="color: #FFD36B;" href="#PointJS.vector.point">point</a>(',
	'.v2d(' : '.<a style="color: #FFD36B;" href="#PointJS.vector.v2d">v2d</a>(',
	'.w2h(' : '.<a style="color: #FFD36B;" href="#PointJS.vector.w2h">w2h</a>(',
	'.getKeyList(' : '.<a style="color: #FFD36B;" href="#PointJS.keyControl.getKeyList">getKeyList</a>(',
	'.getDynamicBox(' : '.<a style="color: #FFD36B;" href="#BaseObject.getDynamicBox">getDynamicBox</a>(',
	'.getStaticBox(' : '.<a style="color: #FFD36B;" href="#BaseObject.getStaticBox">getStaticBox</a>(',
	'.getPosition(' : '.<a style="color: #FFD36B;" href="#BaseObject.getPosition">getPosition</a>(',


	'.Animation(' : '.<a style="color: #FFD36B;" href="#Image.getAnimation">Animation</a>(',


	' Audio.' : '<a style="color: #9C7CD1;" href="#Audio">Audio</a>.',
	' BaseObject.' : '<a style="color: #FFD36B;" href="#BaseObject">BaseObject</a>.',
	' RectObject.' : '<a style="color: #A1FF6F;" href="#RectObject">RectObject</a>.',
	' CircleObject.' : '<a style="color: #FF98AA;" href="#CircleObject">CircleObject</a>.',
	' EllipsObject.' : '<a style="color: #FF98AA;" href="#EllipsObject">EllipsObject</a>.',
	' PolygonObject.' : '<a style="color: #F6A16F;" href="#PolygonObject">PolygonObject</a>.',
	' ImageObject.' : '<a style="color: #F6A16F;" href="#ImageObject">ImageObject</a>.',
	' AnimationObject.' : '<a style="color: #F6A16F;" href="#AnimationObject">AnimationObject</a>.',
	' Mesh.' : '<a style="color: #FFD36B;" href="#Mesh">Mesh</a>.',
	' Image.' : '<a style="color: #FFD36B;" href="#Image">Image</a>.',



	'.BaseObject(' : '.<a style="color: #FFD36B;" href="#BaseObject">BaseObject</a>(',
	'.RectObject(' : '.<a style="color: #A1FF6F;" href="#RectObject">RectObject</a>(',
	'.CircleObject(' : '.<a style="color: #A1FF6F;" href="#CircleObject">CircleObject</a>(',
	'.EllipsObject(' : '.<a style="color: #A1FF6F;" href="#EllipsObject">EllipsObject</a>(',
	'.PolygonObject(' : '.<a style="color: #F6A16F;" href="#PolygonObject">PolygonObject</a>(',
	'.ImageObject(' : '.<a style="color: #F6A16F;" href="#ImageObject">ImageObject</a>(',
	'.AnimationObject(' : '.<a style="color: #F6A16F;" href="#AnimationObject">AnimationObject</a>(',
	'.Image(' : '.<a style="color: #FFD36B;" href="#Image">Image</a>(',
	'.Audio(' : '.<a style="color: #9C7CD1;" href="#Audio">Audio</a>(',



	' .' : ' ',
	'false' : '<span style="color: #FF2C2C;">false</span>',
	'true' : '<span style="color: #7EFF2C;">true</span>'
};













var api = {

	'PointJS' : {
		name     : 'HTML5 Game Engine',
		type     : 'GLOBAL Object',
		api      : 'var ___ = new PointJS("2d", width, height, style);',
		note     : '2d - пока обязательный <br />\
		width - ширина канваса<br />\
		height - высота канваса<br />\
		style - объект { свойство : значение }<br />',
		example  : 'var game = new PointJS("2d", 640, 480, {backgroundColor : "black", border : "1px solid"});',
		returned : 'PointJS object'
	},


 // system
 'PointJS.system.log' : {
 	name     : 'Аналог console.log',
 	type     : 'function',
 	api      : '(message);',
 	note     : 'Сообщение в консоль',
 	example  : 'PointJS.system.log("Этот текст отобразится в консоли");',
 	returned : ''
 },

 'PointJS.system.setStyle' : {
 	name     : 'Установить стиль канвасу',
 	type     : 'function',
 	api      : '(obj);',
 	note     : 'obj - object, набор стилей',
 	example  : 'PointJS.system.setStyle( { backgroundColor : "black" } );',
 	returned : ''
 },

 'PointJS.system.resize' : {
 	name     : 'Установить новую высоту и ширину',
 	type     : 'function',
 	api      : '(w, h);',
 	note     : 'w - number, новая ширина сцены > h - number, новая высота сцены',
 	example  : 'PointJS.system.resize( { 840, 480 );',
 	returned : ''
 },

 'PointJS.system.setSettings' : {
 	name     : 'Установка настроек',
 	type     : 'function',
 	api      : '(settings);',
 	note     : 'settings = {\
 		>`isShowError : true, // Отображать ошибки в консоли\
 		>`isStopForError : true, // Останавливать выполнение игры при ошибках\
 		>`isAutoClear : false, // автоматическая очистка сцены\
 		>`isAutoDraw : false // автоматическая отрисовка объектов\
 		>}',
 		example  : 'PointJS.system.setSettings({isAutoDraw : true, isAutoClear : true});',
 		returned : ''
 	},

 	'PointJS.system.setDefaultSettings' : {
 		name     : 'Установка стандартных настроек канваса',
 		type     : 'function',
 		api      : '(settings);',
 		note     : 'settings = {\
 			>`набор свойств, доступных канвасу\
 			>}',
 			example  : 'PointJS.system.setDefaultSettings({>`fillStyle : "#CF2C2C">});',
 			returned : ''
 		},

 		'PointJS.system.delEvent' : {
 			name     : 'Удаление системного события',
 			type     : 'function',
 			api      : '(evt, key);',
 			note     : 'evt = группа событий >key = имя пользовательского события',
 			example  : 'PointJS.system.delEvent("onload", "myEvent");',
 			returned : ''
 		},

 		'PointJS.system.addEvent' : {
 			name     : 'Добавление системного события',
 			type     : 'function',
 			api      : '(evt, key, func);',
 			note     : 'evt = группа событий >\
 			key = имя пользовательского события >\
 			func = функция обработчик',
 			example  : 'PointJS.system.addEvent("onload", "myEvent", function () {>`alert("Страница загружена полностью");>});',
 			returned : ''
 		},

 		'PointJS.system.attachDOM' : {
 			name     : 'Прикрепление объекта к DOM дереву',
 			type     : 'function',
 			api      : '(HTMLObject);',
 			note     : 'HTMLObject - любой созданный функцией createElement объект',
 			example  : 'var myDIV = document.createElement("div"); >\
 			myDIV.innerHTML = "Новый элемент"; >\
 			PointJS.system.attachDOM(myDIV);',
 			returned : ''
 		},

 		'PointJS.system.initFullPage' : {
 			name     : 'Развертывание игры на всю страницу',
 			type     : 'function',
 			api      : '(без аргументов);',
 			note     : 'Разворачивает канвас по высоте и ширине браузера',
 			example  : 'PointJS.system.initFullPage();',
 			returned : ''
 		},

 		'PointJS.system.exitFullPage' : {
 			name     : 'Вернуть исходный размер',
 			type     : 'function',
 			api      : '(без аргументов);',
 			note     : 'вернет канвас к исходному размеру',
 			example  : 'PointJS.system.exitFullPage();',
 			returned : ''
 		},

 		'PointJS.system.initFullScale' : {
 			name     : 'Растягивание игры на всю страницу',
 			type     : 'function',
 			api      : '(без аргументов);',
 			note     : 'Растягивает канвас по высоте и ширине браузера',
 			example  : 'PointJS.system.initFullScale();',
 			returned : ''
 		},

 		'PointJS.system.exitFullScale' : {
 			name     : 'Вернуть исходный размер',
 			type     : 'function',
 			api      : '(без аргументов);',
 			note     : 'Растягивает канвас по высоте и ширине браузера',
 			example  : 'PointJS.system.exitFullScale();',
 			returned : ''
 		},

 		'PointJS.system.getWH' : {
 			name     : 'Получить размер доступной области браузера',
 			type     : 'function',
 			api      : '(без аргументов);',
 			note     : 'Получение ширины и высоты доступной для использования области окна браузера',
 			example  : 'PointJS.system.getWH();',
 			returned : ' .size() > Размеры области браузера'
 		},

 		'PointJS.system.getInfo' : {
 			name     : 'Получить информацию о движке',
 			type     : 'function',
 			api      : '(без аргументов);',
 			note     : 'Получение информации о движке, авторах, версии',
 			example  : 'PointJS.system.getInfo();',
 			returned : 'object > Информацию о версии движка'
 		},

 		'PointJS.system.initFPSCheck' : {
 			name     : 'Инициализация счетчика FPS',
 			type     : 'function',
 			api      : '(без аргументов);',
 			note     : 'Требуется вызвать перед запуском игры, чтобы иметь доступ к статистике по FPS игры',
 			example  : 'PointJS.system.initFPSCheck();',
 			returned : ''
 		},

 		'PointJS.system.getFPS' : {
 			name     : 'Получить значение FPS',
 			type     : 'function',
 			api      : '(без аргументов);',
 			note     : 'Поучение текущего количества кадров в секунду',
 			example  : 'PointJS.system.getFPS();',
 			returned : 'number > Значение FPS'
 		},


	// vector
	'PointJS.vector.point' : {
		name     : 'Точка в 2D пространстве',
		type     : 'function',
		api      : '(x, y);',
		note     : 'x, y - координаты в пространстве. > \
		Функция является конструктором, может быть присвоена переменной.',
		example  : 'var myPoint = PointJS.vector.point(50, 45); // x - 50, y - 45',
		returned : 'object > Координаты в пространстве > Доступ к свойствам: > `myPoint.x, myPoint.y'
	},

	'PointJS.vector.v2d' : {
		name     : 'Вектор в 2D пространстве',
		type     : 'function',
		api      : '(x, y);',
		note     : 'x, y - координаты в пространстве. > \
		Функция является конструктором, может быть присвоена переменной.',
		example  : 'var myVector = PointJS.vector.v2d(50, 45); // x - 50, y - 45',
		returned : 'object > Координаты в пространстве > Доступ к свойствам: > `myVector.x, myVector.y'
	},

	'PointJS.vector.size' : {
		name     : 'Ширина и высота',
		type     : 'function',
		api      : '(w, h);',
		note     : 'w, h - ширина и высота в пространстве. > \
		Функция является конструктором, может быть присвоена переменной.',
		example  : 'var mySize = PointJS.vector.size(50, 45); // width - 50, height - 45',
		returned : 'object > Ширина и высота > Доступ к свойствам: > `mySize.w, mySize.h'
	},

	'PointJS.vector.w2h' : {
		name     : 'Ширина и высота',
		type     : 'function',
		api      : '(w, h);',
		note     : 'w, h - ширина и высота в пространстве. > \
		Функция является конструктором, может быть присвоена переменной.',
		example  : 'var mySize = PointJS.vector.w2h(50, 45); // width - 50, height - 45',
		returned : ' .size()'
	},

	'PointJS.vector.getPointAngle' : {
		name     : 'Получение новых координат точки после вращения',
		type     : 'function',
		api      : '(point, center, angle);',
		note     : 'point - vector.point() >\
		center - vector.point() > \
		angle - угол в градусах',
		example  : 'var mySize = PointJS.vector.getPointAngle( .point(10, 20), 45 ); // x - 50, y - 45, angle - 45',
		returned : ' .point()'
	},

	'PointJS.vector.isPointIn' : {
		name     : 'Проверка вхождения точки в область, построенную на основе массива point() объектов',
		type     : 'function',
		api      : '(point, area);',
		note     : 'point - vector.point() >\
		area - массив .point() объектов',
		example  : 'PointJS.vector.isPointIn( .point(10, 20), [ .point(0,0), .point(50,0), .point(50,50) ] );',
		returned : 'boolean > true - входит, > false - не входит'
	},

	'PointJS.vector.pointMinus' : {
		name     : 'Получение новых координат после вычитания векторов',
		type     : 'function',
		api      : '(point, vector2D);',
		note     : 'point - vector.point() >\
		vector2D - vector.v2d()',
		example  : 'var newPoint = PointJS.vector.pointMinus( .point(10, 20), .v2d(5, 5) );',
		returned : ' .point()'
	},

	'PointJS.vector.pointPlus' : {
		name     : 'Получение новых координат после сложения векторов',
		type     : 'function',
		api      : '(point, vector2D);',
		note     : 'point - vector.point() >\
		vector2D - vector.v2d()',
		example  : 'var newPoint = PointJS.vector.pointPlus( .point(10, 20), .v2d(5, 5) );',
		returned : ' .point()'
	},

	'PointJS.vector.pointInc' : {
		name     : 'Получение новых координат после умножения векторов',
		type     : 'function',
		api      : '(point, vector2D);',
		note     : 'point - vector.point() >\
		vector2D - vector.v2d()',
		example  : 'var newPoint = PointJS.vector.pointInc( .point(10, 20), .v2d(5, 5) );',
		returned : ' .point()'
	},

	'PointJS.vector.pointDiv' : {
		name     : 'Получение новых координат после деления векторов',
		type     : 'function',
		api      : '(point, vector2D);',
		note     : 'point - vector.point() >\
		vector2D - vector.v2d()',
		example  : 'var newPoint = PointJS.vector.pointDiv( .point(10, 20), .v2d(5, 5) );',
		returned : ' .point()'
	},

	'PointJS.vector.pointAbs' : {
		name     : 'Получение абсолютных координат',
		type     : 'function',
		api      : '(point);',
		note     : 'point - vector.point()',
		example  : 'var newPoint = PointJS.vector.pointAbs( .point(10, -20) );',
		returned : ' .point()'
	},

	'PointJS.vector.getMidPoint' : {
		name     : 'Получение средней точки (середины отрезка)',
		type     : 'function',
		api      : '(pointA, pointB);',
		note     : 'pointA, pointB - vector.point()',
		example  : 'var midPoint = PointJS.vector.getMidPoint( .point(10, -20), .point(100, 15) );',
		returned : ' .point()'
	},

	'PointJS.vector.getDistance' : {
		name     : 'Получение расстояния между двумя точками',
		type     : 'function',
		api      : '(pointA, pointB);',
		note     : 'pointA, pointB - vector.point()',
		example  : 'var dist = PointJS.vector.getDistance( .point(10, -20), .point(100, 15) );',
		returned : 'number > Расстояние между точками'
	},

	'PointJS.vector.isSame' : {
		name     : 'Проверка совпадения точек',
		type     : 'function',
		api      : '(pointA, pointB);',
		note     : 'pointA, pointB - vector.point()',
		example  : 'var midPoint = PointJS.vector.isSame( .point(10, -20), .point(100, 15) );',
		returned : 'boolean > true - совпадают > false - не совпадают'
	},

	'PointJS.math.limit' : {
		name     : 'Ограничение числа по модулю',
		type     : 'function',
		api      : '(numb, max);',
		note     : 'numb - number > \
		max - number',
		example  : 'var newNumb = PointJS.math.limit( 10, 8 ); // 8 > \
		var newNumb = PointJS.math.limit( -5, -4 ); // -4',
		returned : 'number'
	},

	'PointJS.math.a2r' : {
		name     : 'Перевод градусов в радианы',
		type     : 'function',
		api      : '(angle);',
		note     : 'angle - number',
		example  : 'var rad = PointJS.math.a2r( 45 );',
		returned : 'number > Значение в радианах'
	},

	'PointJS.math.random' : {
		name     : 'Получение псевдослучайного числа',
		type     : 'function',
		api      : '(min, max[, bool]);',
		note     : 'min - number, начальная граница > \
		max - number, конечная граница, > \
		bool - boolean, если true - исключается 0 (ноль)',
		example  : 'var randNum = PointJS.math.random( -4, 4, true );',
		returned : 'number > Случайное число в заданных границах'
	},


	'PointJS.keyControl.getKeyList' : {
		name     : 'Получение доступных для использования клавиш',
		type     : 'function',
		api      : '(без аргументов);',
		note     : '',
		example  : 'console.log(PointJS.keyControl.getKeyList());',
		returned : 'array > массив наименований клавиш'
	},

	'PointJS.keyControl.isKeyDown' : {
		name     : 'Проверка удерживания клавиши нажатой',
		type     : 'function',
		api      : '(key);',
		note     : 'key - string, наименование клавиши (см. .getKeyList())',
		example  : 'console.log(PointJS.keyControl.isKeyDown("LEFT"));',
		returned : 'boolean > true - клавиша зажата > false - клавиша не зажата'
	},

	'PointJS.keyControl.isKeyUp' : {
		name     : 'Проверка отпускания клавиши',
		type     : 'function',
		api      : '(key);',
		note     : 'key - string, наименование клавиши (см. .getKeyList())',
		example  : 'console.log(PointJS.keyControl.isKeyUp("A"));',
		returned : 'boolean > true - клавиша была отпущена > false - клавиша не была отпущена'
	},

	'PointJS.keyControl.isKeyPress' : {
		name     : 'Проверка нажатия клавиши',
		type     : 'function',
		api      : '(key);',
		note     : 'key - string, наименование клавиши (см. .getKeyList())',
		example  : 'console.log(PointJS.keyControl.isKeyPress("SPACE"));',
		returned : 'boolean > true - клавиша была нажата > false - клавиша не была нажата'
	},

	'PointJS.keyControl.getInputChar' : {
		name     : 'Получение вводимого с клавиатуры символа',
		type     : 'function',
		api      : '();',
		note     : 'Вернет вводимый символ только при включенном режиме InputMode',
		example  : 'console.log(PointJS.keyControl.getInputChar());',
		returned : 'boolean > false - никакой символ в данный момент не вводится > \
		char > введенный символ'
	},

	'PointJS.keyControl.setInputMode' : {
		name     : 'Включение / отключение режима чтения клавиатуры',
		type     : 'function',
		api      : '(bool);',
		note     : 'bool - boolean, включение или отключение режима чтения символов с клавиатуры',
		example  : 'console.log(PointJS.keyControl.setInputMode( true ));',
		returned : ''
	},


	'PointJS.keyControl.exitKeyControl' : {
		name     : 'Отключение режима перехвата клавиатуры',
		type     : 'function',
		api      : '();',
		note     : 'После отключения режима перехвата клавиатуры события клавиатуры не будут обрабатываться движком.',
		example  : 'console.log(PointJS.keyControl.exitKeyControl());',
		returned : ''
	},

	'PointJS.keyControl.initKeyControl' : {
		name     : 'Включение режима перехвата клавиатуры',
		type     : 'function',
		api      : '();',
		note     : 'Включает режим перехвата клавиатуры. Не используется внутри игрового цикла.',
		example  : 'console.log(PointJS.keyControl.initKeyControl());',
		returned : ''
	},

	'PointJS.mouseControl.getMousePosition' : {
		name     : 'Получение локальной позиции курсора',
		type     : 'function',
		api      : '();',
		note     : 'Вернет локальные координаты курсора мыши',
		example  : 'console.log(PointJS.mouseControl.getMousePosition());',
		returned : ' .point() > Локальная позиция курсора'
	},

	'PointJS.mouseControl.getMousePositionA' : {
		name     : 'Получение глобальной позиции курсора с учетом смещения камеры',
		type     : 'function',
		api      : '();',
		note     : 'Вернет глобальные координаты курсора мыши',
		example  : 'console.log(PointJS.mouseControl.getMousePositionA());',
		returned : ' .point() > Глобальная позиция курсора'
	},

	'PointJS.mouseControl.setMouseImage' : {
		name     : 'Замена стандартного курсора каким-либо изображением',
		type     : 'function',
		api      : '(img);',
		note     : 'img - string, путь к картинке',
		example  : 'PointJS.mouseControl.setMouseImage("img/cursor.png");',
		returned : ''
	},

	'PointJS.mouseControl.setMouseVisible' : {
		name     : 'Скрытие / отображение курсора',
		type     : 'function',
		api      : '(bool);',
		note     : 'bool - boolean, true - показать, false - скрыть',
		example  : 'PointJS.mouseControl.setMouseVisible( false );',
		returned : ''
	},

	'PointJS.mouseControl.isCursorVisivle' : {
		name     : 'Проверка видимости курсора',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'PointJS.mouseControl.isCursorVisivle();',
		returned : 'boolean > true - курсор видимый > false - курсор не видимый'
	},

	'PointJS.mouseControl.isMouseDown' : {
		name     : 'Проверка удержания кнопки мыши',
		type     : 'function',
		api      : '(key);',
		note     : 'key - string, обозрачение кнопки > LEFT, RIGHT, MIDDLE',
		example  : 'console.log(PointJS.mouseControl.isMouseDown("LEFT"));',
		returned : 'boolean > true - кнопка зажата > false - кнопка не зажата'
	},

	'PointJS.mouseControl.isMouseUp' : {
		name     : 'Проверка отпускания кнопки мыши',
		type     : 'function',
		api      : '(key);',
		note     : 'key - string, обозрачение кнопки > LEFT, RIGHT, MIDDLE',
		example  : 'console.log(PointJS.mouseControl.isMouseUp("LEFT"));',
		returned : 'boolean > true - кнопка отпущена > false - кнопка не отпущена'
	},

	'PointJS.mouseControl.isMousePress' : {
		name     : 'Проверка нажатия кнопки мыши',
		type     : 'function',
		api      : '(key);',
		note     : 'key - string, обозрачение кнопки > LEFT, RIGHT, MIDDLE',
		example  : 'console.log(PointJS.mouseControl.isMousePress("MIDDLE"));',
		returned : 'boolean > true - кнопка нажата > false - кнопка не нажата'
	},

	'PointJS.mouseControl.isMouseInStatic' : {
		name     : 'Проверка попадания курсора мыши в StaticBox',
		type     : 'function',
		api      : '(box);',
		note     : 'box - StaticBox, прямоугольная область (см. object.getStaticBox())',
		example  : 'PointJS.mouseControl.isMouseInStatic( object.getStaticBox() );',
		returned : 'boolean > true - курсор попадает в область > false - курсор не попадает в область'
	},

	'PointJS.mouseControl.isMouseInDynamic' : {
		name     : 'Проверка попадания курсора мыши в StaticBox',
		type     : 'function',
		api      : '(box);',
		note     : 'box - DynamicBox, область из точек (см. object.getDynamicBox())',
		example  : 'PointJS.mouseControl.isMouseInDynamic( object.getDynamicBox() );',
		returned : 'boolean > true - курсор попадает в область > false - курсор не попадает в область'
	},

	'PointJS.mouseControl.isMouseWheel' : {
		name     : 'Проверка события колесика мыши',
		type     : 'function',
		api      : '(key);',
		note     : 'key - направление вращения > UP, DOWN',
		example  : 'PointJS.mouseControl.isMouseWheel( "UP" );',
		returned : 'boolean > true - колесико вращается > false - колесико не вращается'
	},

	'PointJS.mouseControl.initMouseLock' : {
		name     : 'Включение режима захвата курсора мыши',
		type     : 'function',
		api      : '();',
		note     : 'Включает захват курсора. Вызывается вне игрового цикла',
		example  : 'PointJS.mouseControl.initMouseLock();',
		returned : ''
	},

	'PointJS.mouseControl.exitMouseLock' : {
		name     : 'Отключение режима захвата курсора мыши',
		type     : 'function',
		api      : '();',
		note     : 'Выключает захват курсора полностью',
		example  : 'PointJS.mouseControl.exitMouseLock();',
		returned : ''
	},

	'PointJS.mouseControl.unlockMouse' : {
		name     : 'Временно разблокирует захваченные курсор',
		type     : 'function',
		api      : '();',
		note     : 'Отобразит курсор мыши до следующего клика по канвасу',
		example  : 'PointJS.mouseControl.unlockMouse();',
		returned : ''
	},

	'PointJS.mouseControl.isMouseLock' : {
		name     : 'Проверить захвачен курсор или нет',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'PointJS.mouseControl.isMouseLock();',
		returned : 'boolean > true - курсор захвачен > false - курсор не захвачен'
	},

	'PointJS.mouseControl.getMouseSpeed' : {
		name     : 'Получить скорость перемещения курсора по осям',
		type     : 'function',
		api      : '();',
		note     : 'Получение скорости курсора возможно только если он захвачен',
		example  : 'PointJS.mouseControl.getMouseSpeed();',
		returned : ' .v2d() > x - скорость перемещения по X > y - скорость перемещения по Y'
	},

	'PointJS.mouseControl.isPeekStatic' : {
		name     : 'Проверить клик по статической области',
		type     : 'function',
		api      : '(key, box);',
		note     : 'key - string, кнопка LEFT, RIGHT, MIDDLE > box - StaticBox, область, в которой проверяется клик',
		example  : 'PointJS.mouseControl.isPeekStatic( object.getStaticBox() );',
		returned : 'boolean > true - клик по области, false - клик не по области, отсутствие клика'
	},

	'PointJS.mouseControl.isPeekDynamic' : {
		name     : 'Проверить клик по динамической области',
		type     : 'function',
		api      : '(key, box);',
		note     : 'key - string, кнопка LEFT, RIGHT, MIDDLE > box - DynamicBox, область, в которой проверяется клик',
		example  : 'PointJS.mouseControl.isPeekDynamic( object.getDynamicBox() );',
		returned : 'boolean > true - клик по области, false - клик не по области, отсутствие клика'
	},

	'PointJS.mouseControl.initMouseControl' : {
		name     : 'Включение режима перехвата событий мыши',
		type     : 'function',
		api      : '();',
		note     : 'Обработчик событий мыши. Вызывает вне игрового цикла',
		example  : 'PointJS.mouseControl.initMouseControl();',
		returned : ''
	},

	'PointJS.mouseControl.exitMouseControl' : {
		name     : 'Выключение режима перехвата событий мыши',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'PointJS.mouseControl.exitMouseControl();',
		returned : ''
	},

	'PointJS.touchControl.initTouchControl' : {
		name     : 'Включение перехвата сенсора',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'PointJS.touchControl.initTouchControl();',
		returned : ''
	},

	'PointJS.touchControl.getFixPosition' : {
		name     : 'Получение координат фиксатора касания',
		type     : 'function',
		api      : '();',
		note     : 'Фиксатор касания - это позиция первоначального прикосновения к сенсору.',
		example  : 'var fixPos = PointJS.touchControl.getFixPosition();',
		returned : ' .point() > Позиция касания'
	},

	'PointJS.touchControl.getFixPositionA' : {
		name     : 'Получение координат фиксатора касания в абсолютных координатах',
		type     : 'function',
		api      : '();',
		note     : 'Фиксатор касания - это позиция первоначального прикосновения к сенсору.',
		example  : 'var fixPos = PointJS.touchControl.getFixPositionA();',
		returned : ' .point() > Позиция касания'
	},

	'PointJS.touchControl.getRun' : {
		name     : 'Получение расстояния по осям от фиксатора',
		type     : 'function',
		api      : '();',
		note     : 'Возвращает расстояние по осям, пройденное жестом от фиксатора.',
		example  : 'var run = PointJS.touchControl.getRun();',
		returned : ' .v2d() > x - расстояние по оси X > y : расстояние по оси Y'
	},

	'PointJS.touchControl.getVector' : {
		name     : 'Получение вектора направления жеста по осям',
		type     : 'function',
		api      : '();',
		note     : 'Возвращает вектор направления движения жеста.',
		example  : 'var vector = PointJS.touchControl.getVector();',
		returned : ' .v2d() > x - вектор по оси X. Если больше 0 - движение вправо, иначе - влево > \
																								y : вектор по оси Y. Если больше 0 - движение вниз, иначе - вверх'
	},

	'PointJS.touchControl.isTouchDown' : {
		name     : 'Проверка удерживания касания',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'var down = PointJS.touchControl.isTouchDown();',
		returned : 'boolean > true - прикосновение удерживается > false - прикосновения нет'
	},

	'PointJS.touchControl.isTouchPress' : {
		name     : 'Проверка однократного касания',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'var press = PointJS.touchControl.isTouchPress();',
		returned : 'boolean > true - прикосновение есть > false - прикосновения нет'
	},

	'PointJS.touchControl.isTouchUp' : {
		name     : 'Проверка завершения касания',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'var up = PointJS.touchControl.isTouchUp();',
		returned : 'boolean > true - прикосновение завершено (палец убран) > false - прикосновения нет или палец не убран'
	},

	'PointJS.touchControl.getTouchPositionA' : {
		name     : 'Получение координат прикосновения в абсолютных координатах',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'var point = PointJS.touchControl.getTouchPositionA();',
		returned : ' .point() > Координаты прикосновения'
	},

	'PointJS.touchControl.getTouchPosition' : {
		name     : 'Получение координат прикосновения',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'var point = PointJS.touchControl.getTouchPosition();',
		returned : ' .point() > Координаты прикосновения'
	},

	'PointJS.touchControl.isPeekStatic' : {
		name     : 'Тач (касание) по статической области',
		type     : 'function',
		api      : '(StaticBox);',
		note     : '',
		example  : 'var peek = PointJS.touchControl.isPeekStatic( obj.getStaticBox() );',
		returned : 'boolean > true - касание попало в статическую область > false - не попало'
	},

	'PointJS.touchControl.isPeekDynamic' : {
		name     : 'Тач (касание) по динамической области',
		type     : 'function',
		api      : '(DynamicBox);',
		note     : '',
		example  : 'var peek = PointJS.touchControl.isPeekDynamic( obj.getDynamicBox() );',
		returned : 'boolean > true - касание попало в динамическую область > false - не попало'
	},

	'PointJS.touchControl.isTouchInStatic' : {
		name     : 'Проверка попадания прикосновения в статическую область StaticBox',
		type     : 'function',
		api      : '(StaticBox);',
		note     : '',
		example  : 'var bool = PointJS.touchControl.isTouchInStatic( obj.getStaticBox() );',
		returned : 'boolean > true - касание попало в статическую область > false - не попало'
	},

	'PointJS.touchControl.isTouchInDynamic' : {
		name     : 'Проверка попадания прикосновения в динамическую область DynamicBox',
		type     : 'function',
		api      : '(DynamicBox);',
		note     : '',
		example  : 'var bool = PointJS.touchControl.isTouchInDynamic( obj.getDynamicBox() );',
		returned : 'boolean > true - касание попало в динамическую область > false - не попало'
	},

	'PointJS.touchControl.getTouches' : {
		name     : 'Получение массива прикосновений',
		type     : 'function',
		api      : '();',
		note     : 'Функция возвращает массив с координатами прикосновений. > \
														где каждый элемент массива это объект со следующими меременными: > \
														x : абсолютная координата X прикосновения > \
														y : абсолютная координата Y прикосновения > \
														screenX : координата X прикосновения > \
														screenY : координата X прикосновения > \
														Рекомендуется использовать x и y координаты.',
		example  : 'var arr = PointJS.touchControl.getTouches(  );',
		returned : 'array > массив с координатами прикосновений'
	},

	'PointJS.touchControl.exitTouchControl' : {
		name     : 'Отключение режима перехвата сенсора',
		type     : 'function',
		api      : '();',
		note     : '',
		example  : 'PointJS.touchControl.exitTouchControl(  );',
		returned : ''
	},

	'PointJS.colors.rgb' : {
		name     : 'Генерация непрозрачного цвета',
		type     : 'function',
		api      : '(r, g, b);',
		note     : 'r - int [0-255], красный цвет > \
		g - int [0-255], зеленый цвет > \
		b - int [0-255], синий цвет',
		example  : 'PointJS.colors.rgb(255, 0, 0);',
		returned : 'string > строка, содержащая цвет'
	},

	'PointJS.colors.rgba' : {
		name     : 'Генерация цвета с возможностью указать прозрачность',
		type     : 'function',
		api      : '(r, g, b, a);',
		note     : 'r - int [0-255], красный цвет > \
		g - int [0-255], зеленый цвет > \
		b - int [0-255], синий цвет > \
		a - float [0-1], прозрачность',
		example  : 'PointJS.colors.rgba(255, 0, 0, 0.5);',
		returned : 'string > строка, содержащая цвет'
	},

	'PointJS.colors.h2r' : {
		name     : 'Генерация цвета из его шестнадцатеричного представления',
		type     : 'function',
		api      : '(hex, a);',
		note     : 'hex - цвет в формате #FFFFFF (обязательно полная запись) > \
		a - float [0-1], прозрачность',
		example  : 'PointJS.colors.h2r("#B35E5E", 0.5);',
		returned : 'string > строка, содержащая цвет'
	},

	'PointJS.colors.randomColor' : {
		name     : 'Генерация случайного цвета в заданных рамках',
		type     : 'function',
		api      : '(min, max, alpha);',
		note     : 'nim - нижняя граница цвета > \
														max - верхняя граница цвета > \
														a - float [0-1], прозрачность',
		example  : 'PointJS.colors.randomColor("#B35E5E", 0.5);',
		returned : 'string > строка, содержащая цвет'
	},

	'PointJS.OOP.isDef' : {
		name     : 'Проверка существования объекта, свойства объекта, переменной',
		type     : 'function',
		api      : '(obj[, key]);',
		note     : 'obj - object || variable - проверяемое значение > \
		key - свойство объекта, может быть строкой либо идентификатором в цикле for in',
		example  : 'PointJS.OOP.isDef(myObj.level); // проверка существования myObj.level > \
		PointJS.OOP.isDef(myObj, "level"); // проверка существования myObj.level > \
		for (i in object) { > `if (isDef(object, i)) > ``console.log(true); > }',
			returned : 'boolean > true - совйство|объект|переменная существует > false - не существует'
	},

	'PointJS.OOP.unDef' : {
		name     : 'Удаление свойства объекта',
		type     : 'function',
		api      : '(obj, key);',
		note     : 'obj - object, объект > \
		key - свойство объекта, может быть строкой либо идентификатором в цикле for in',
		example  : 'PointJS.OOP.unDef(myObj, level); // удаление свойства myObj.level',
		returned : ''
	},

	'PointJS.OOP.toString' : {
		name     : 'Преобразование объекта в строку',
		type     : 'function',
		api      : '(obj[, convertNumberToInt]);',
		note     : 'obj - object, объект для конвертации > \
		convertNumberToInt - boolean, флаг, отвечающий за конвертацию числовых значений в объекте в целый тип.',
		example  : 'PointJS.OOP.toString( {x : 15, name : "my name"} );',
		returned : 'string > Конвертированный в строку объект'
	},

	'PointJS.game.createLoop' : {
		name     : 'Создание игрового цикла',
		type     : 'function',
		api      : '(name, func);',
		note     : 'name - string, наименование игрового состояния > \
		func - function, функция, описывающая логику и поведение в игровом цикле',
		example  : 'PointJS.game.createLoop( "myGame", function () {> `/*игровой цикл*/ >} );',
		returned : ''
	},

	'PointJS.game.setLoop' : {
		name     : 'Задать активный игровой цикл',
		type     : 'function',
		api      : '(name);',
		note     : 'name - string, наименование игрового состояния',
		example  : 'PointJS.game.setLoop( "myGame" );',
		returned : ''
	},

	'PointJS.game.setLoopSound' : {
		name     : 'Установить плейлист для фонового проигрывания',
		type     : 'function',
		api      : '(gameLoop, arrAudio);',
		note     : 'gameLoop - string, наименования игрового состояния > \
														arrAudio - массив .Audio() файлов',
		example  : 'PointJS.game.setLoopSound( [audio1, audio2, ... , audioN] );',
		returned : ''
	},

	'PointJS.game.start' : {
		name     : 'Запустить активный игровой цикл',
		type     : 'function',
		api      : '([fps]);',
		note     : 'fps - number, скорость работы игрового состояния',
		example  : 'PointJS.game.start( 60 );',
		returned : ''
	},

	'PointJS.game.stop' : {
		name     : 'Остановить выполнение',
		type     : 'function',
		api      : '();',
		note     : 'Выполнение останавливается, но можно продолжить функцией restart()',
		example  : 'PointJS.game.stop();',
		returned : ''
	},

	'PointJS.game.fillContext' : {
		name     : 'Залить контекст',
		type     : 'function',
		api      : '(color);',
		note     : 'color - string, цвет заливки',
		example  : 'PointJS.game.fillContext("#E1C8C8");',
		returned : ''
	},

	'PointJS.system.setContextSettings' : {
		name     : 'Предварительная настройка контекста',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, объект, содержаний настройки в формате ключ : значение',
		example  : 'PointJS.system.setContextSettings({> `globalAlpha : 0.2, > `strokeStyle : "red" >});',
		returned : ''
	},

	'PointJS.system.defaultSettings' : {
		name     : 'Восстановление дефолтных настроек контекста',
		type     : 'function',
		api      : '();',
		note     : 'Вернет настройки, присовенные функцией setDefaultSettings()',
		example  : 'PointJS.system.defaultSettings();',
		returned : ''
	},

	'PointJS.game.restart' : {
		name     : 'Продолжить выполнение игры',
		type     : 'function',
		api      : '();',
		note     : 'Выполнение продолжается, если было ранее остановлено функцией stop()',
		example  : 'PointJS.game.restart();',
		returned : ''
	},

	'PointJS.game.newBaseObject' : {
		name     : 'Создать объект типа BaseObject',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор предустановок к создаваемому объекту > \
														{ > \
														`x - number, позиция по X > \
														`y - number, позицию по Y > \
														`w - number, ширина объекта > \
														`h - number, высота объекта > \
														`fillColor - string, цвет заливки объекта > \
														`strokeColor - string, цвет обводки объекта > \
														`strokeWidth - number, ширина линии обводки > \
														`angle - number, угол наклона в градусах > \
														`alpha - number, степень прозрачности объекта [0..1] > \
														`userData - object, набор дополнительных свойств. Аналог вызова setUserData() > \
														`visible - boolean, видимость объекта > \
														} > Все параметры не являются обязательными',
		example  : 'var obj = game.newBaseObject( \
														{ > \
														`x : 100, > \
														`y : 100, > \
														`w : 50, > \
														`h : 50, > \
														`fillColor : "#FBFE6F", > \
														`strokeColor : "#DA4848", > \
														`strokeWidth : 2, > \
														`angle : 0, > \
														`alpha : 1, > \
														`visible : true > \
														});',
		returned : ' .BaseObject() > Базовый объект'
	},

	'PointJS.game.newRectObject' : {
		name     : 'Создать объект типа RectObject',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор предустановок к создаваемому объекту > \
														{ > \
														`x - number, позиция по X > \
														`y - number, позицию по Y > \
														`w - number, ширина объекта > \
														`h - number, высота объекта > \
														`fillColor - string, цвет заливки объекта > \
														`strokeColor - string, цвет обводки объекта > \
														`strokeWidth - number, ширина линии обводки > \
														`angle - number, угол наклона в градусах > \
														`alpha - number, степень прозрачности объекта [0..1] > \
														`userData - object, набор дополнительных свойств. Аналог вызова setUserData() > \
														`visible - boolean, видимость объекта > \
														} > Все параметры не являются обязательными',
		example  : 'var obj = game.newBaseObject( \
														{ > \
														`x : 100, > \
														`y : 100, > \
														`w : 50, > \
														`h : 50, > \
														`fillColor : "#FBFE6F", > \
														`strokeColor : "#DA4848", > \
														`strokeWidth : 2, > \
														`angle : 0, > \
														`alpha : 1, > \
														`visible : true > \
														});',
		returned : ' .RectObject() > объект "Прямоугольник"'
	},

	'PointJS.game.newCircleObject' : {
		name     : 'Создать объект типа CircleObject',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор предустановок к создаваемому объекту > \
														{ > \
														`x - number, позиция по X > \
														`y - number, позицию по Y > \
														`radius - number, радиус окружности > \
														`fillColor - string, цвет заливки объекта > \
														`strokeColor - string, цвет обводки объекта > \
														`strokeWidth - number, ширина линии обводки > \
														`angle - number, угол наклона в градусах > \
														`alpha - number, степень прозрачности объекта [0..1] > \
														`userData - object, набор дополнительных свойств. Аналог вызова setUserData() > \
														`visible - boolean, видимость объекта > \
														} > Все параметры не являются обязательными',
		example  : 'var obj = game.newBaseObject( \
														{ > \
														`x : 100, > \
														`y : 100, > \
														`radius : 10, > \
														`fillColor : "#FBFE6F", > \
														`strokeColor : "#DA4848", > \
														`strokeWidth : 2, > \
														`angle : 0, > \
														`alpha : 1, > \
														`visible : true > \
														});',
		returned : ' .CircleObject() > объект "Окружность"'
	},

	'PointJS.game.newEllipsObject' : {
		name     : 'Создать объект типа EllipsObject',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор предустановок к создаваемому объекту > \
														{ > \
														`x - number, позиция по X > \
														`y - number, позицию по Y > \
														`w - number, ширина объекта > \
														`h - number, высота объекта > \
														`fillColor - string, цвет заливки объекта > \
														`strokeColor - string, цвет обводки объекта > \
														`strokeWidth - number, ширина линии обводки > \
														`angle - number, угол наклона в градусах > \
														`alpha - number, степень прозрачности объекта [0..1] > \
														`userData - object, набор дополнительных свойств. Аналог вызова setUserData() > \
														`visible - boolean, видимость объекта > \
														} > Все параметры не являются обязательными',
		example  : 'var obj = game.newBaseObject( \
														{ > \
														`x : 100, > \
														`y : 100, > \
														`w : 50, > \
														`h : 50, > \
														`fillColor : "#FBFE6F", > \
														`strokeColor : "#DA4848", > \
														`strokeWidth : 2, > \
														`angle : 0, > \
														`alpha : 1, > \
														`visible : true > \
														});',
		returned : ' .EllipsObject() > объект "элипс"'
	},

	'PointJS.game.newPolygonObject' : {
		name     : 'Создать объект типа PolygonObject',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор предустановок к создаваемому объекту > \
														{ > \
														`x - number, позиция по X > \
														`y - number, позицию по Y > \
														`points - array .point() объектов, набор точек > \
														`pointColor - string, цвет вершин > \
														`fillColor - string, цвет заливки объекта > \
														`strokeColor - string, цвет обводки объекта > \
														`strokeWidth - number, ширина линии обводки > \
														`angle - number, угол наклона в градусах > \
														`alpha - number, степень прозрачности объекта [0..1] > \
														`userData - object, набор дополнительных свойств. Аналог вызова setUserData() > \
														`visible - boolean, видимость объекта > \
														} > Все параметры не являются обязательными',
		example  : 'var obj = game.newBaseObject( \
														{ > \
														`x : 100, > \
														`y : 100, > \
														`points : [ .point(0, 0), .point(10, 0), .point(10, 10), .point(0, 10) ], > \
														`pointColor : "#343DE4", > \
														`fillColor : "#FBFE6F", > \
														`strokeColor : "#DA4848", > \
														`strokeWidth : 2, > \
														`angle : 0, > \
														`alpha : 1, > \
														`visible : true > \
														});',
		returned : ' .PolygonObject() > объект "Прямоугольник"'
	},

	'PointJS.game.newImageObject' : {
		name     : 'Создать объект типа ImageObject',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор предустановок к создаваемому объекту > \
														{ > \
														`file - string, путь к изображению, > \
														`x - number, позиция по X > \
														`y - number, позицию по Y > \
														`w - number, ширина объекта > \
														`h - number, высота объекта > \
														`angle - number, угол наклона в градусах > \
														`alpha - number[0..1], степень прозрачности объекта > \
														`scale - number[0..1], масштабирование изрбражения (только если w и h не заданы)> \
														`userData - object, набор дополнительных свойств. Аналог вызова setUserData() > \
														`visible - boolean, видимость объекта > \
														} > Все параметры не являются обязательными',
		example  : 'var obj = game.newBaseObject( \
														{ > \
														`file : "images/ball.png", > \
														`x : 100, > \
														`y : 100, > \
														`w : 50, > \
														`h : 50, > \
														`angle : 0, > \
														`alpha : 1, > \
														`//scale : 0.5, // уменьшить картинку в 2 раза, если не заданы ширина и высота> \
														`visible : true > \
														});',
		returned : ' .ImageObject() > объект "Изображение"'
	},

	'PointJS.game.newAnimationObject' : {
		name     : 'Создать объект типа AnimationObject',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор предустановок к создаваемому объекту > \
														{ > \
														`animation - .Animation(), объект анимации > \
														`delay - number, замедление анимации (в FPS) > \
														`x - number, позиция по X > \
														`y - number, позицию по Y > \
														`w - number, ширина объекта > \
														`h - number, высота объекта > \
														`angle - number, угол наклона в градусах > \
														`alpha - number, степень прозрачности объекта [0..1] > \
														`userData - object, набор дополнительных свойств. Аналог вызова setUserData() > \
														`visible - boolean, видимость объекта > \
														} > Все параметры не являются обязательными',
		example  : 'var obj = game.newBaseObject( \
														{ > \
														`animation : tiles.newImage("images/human.png").getAnimation(0, 0, 20, 40, 5), > \
														`x : 100, > \
														`y : 100, > \
														`w : 20, > \
														`h : 40, > \
														`angle : 0, > \
														`alpha : 1, > \
														`visible : true > \
														});',
		returned : ' .AnimationObject() > объект "Анимация"'
	},

	'PointJS.game.newMesh' : {
		name     : 'Создать объект типа Mesh',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор предустановок к создаваемому объекту > \
														{ > \
														`x - number, позиция по X > \
														`y - number, позицию по Y > \
														`angle - number, угол наклона в градусах > \
														`add - array, массив объектов, наследующих .BaseObject() > \
														} > Все параметры не являются обязательными',
		example  : 'var obj = game.newBaseObject( \
														{ > \
														`x : 100, > \
														`y : 100, > \
														`angle : 0, > \
														`add : [obj1, obj2] > \
														});',
		returned : ' .Mesh() > объект "Окружность"'
	},

	'PointJS.game.moveCamera' : {
		name     : 'Двигать камеру в направлении',
		type     : 'function',
		api      : '(vector2D);',
		note     : 'vector2D - .v2d(), направление движения камеры',
		example  : 'PointJS.game.moveCamera( .v2d(1, 0) );',
		returned : ''
	},

	'PointJS.game.setCameraPosition' : {
		name     : 'Установить камеру в позицию',
		type     : 'function',
		api      : '(point);',
		note     : 'point - .point(), позиция, в которую нужно установить камеру',
		example  : 'PointJS.game.setCameraPosition( .point(100, 100) );',
		returned : ''
	},

	'PointJS.game.clearContext' : {
		name     : 'Очистить все, что было отрисовано',
		type     : 'function',
		api      : '();',
		note     : 'Вызывается перед новыми отрисовками, иначе игрок ничего не увидит',
		example  : 'PointJS.game.clearContext();',
		returned : ''
	},

	 // tiles
	'PointJS.tiles.newImage' : {
		name     : 'Новое изображение',
		type     : 'function',
		api      : '(obj);',
		note     : 'Создает новый объект Image, который можно в дальнейшем использовать для построения анимации',
		example  : 'PointJS.tiles.newImage();',
		returned : ' .Image() > Изображение'
	},


	'PointJS.brush.drawPolygon' : {
		name     : 'Отрисовать полигон',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор свойств >\
		{ >\
			`points : [ .point(0, 0), .point(10, 0), .point(10, 10), .point(0, 10) ], // array, набор вершин полигона > \
			`[fillColor : "red",] // string, цвет заливки> \
			`[strokeColor : "black",] // string, цвет отрисовки ребер > \
			`[strokeWidth : 2,] // number, ширина отрисованных граней (линий)> \
			`[pointColor : "white"] // цвет отрисовки вершин (точек)> \
		}',
		example  : 'PointJS.brush.drawPolygon({> `points : [ .point(0, 0), .point(10, 0), .point(10, 10), .point(0, 10) ], >`pointColor : "red" >});',
		returned : ''
	},

	'PointJS.brush.drawText' : {
		name     : 'Отрисовать текст',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор свойств >\
		{ >\
			`x : 10, // number, позиция по X > \
			`y : 50, // number, позиция по Y > \
			`text : "Helki, World!", // текст, который нужно отрисовать > \
			`[color : "red",] // string, цвет заливки > \
			`[size : 13,] // number, размер шрифта > \
			`[font : "serif",] // string, шрифт текста > \
		}',
		example  : 'PointJS.brush.drawText({> `text : "Привет всем!", > `x : 20, y : 20, >`color : "black" >});',
		returned : ''
	},

	'PointJS.brush.drawTextLines' : {
		name     : 'Отрисовать многострочный текст',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор свойств >\
		{ >\
			`x : 10, // number, позиция по X > \
			`y : 50, // number, позиция по Y > \
			`lines : [ "Hello, World!", "New Line!" ], // массив сторк, новый элемент - новая строка > \
			`[color : "red",] // string, цвет заливки > \
			`[size : 13,] // number, размер шрифта > \
			`[font : "serif",] // string, шрифт текста > \
		}',
		example  : 'PointJS.brush.drawTextLines({> `text : "Привет всем!", > `x : 20, y : 20, >`color : "black" >});',
		returned : ''
	},

	'PointJS.brush.drawRect' : {
		name     : 'Отрисовать прямоугольник',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор свойств >\
		{ >\
			`x : 10, // number, позиция по X > \
			`y : 50, // number, позиция по Y > \
			`w : 20, // number, ширина прямоугольника > \
			`h : 10, // number, высота прямоугольника  > \
			`[fillColor : "red",] // string, цвет заливки > \
			`[strokeColor : "white",] // string, цвет линии обводки > \
			`[strokeWidth : 2] // number, ширина линии обводки > \
		}',
		example  : 'PointJS.brush.drawRect({> `x : 20, y : 20, > `w : 40, h : 20, >`color : "black" >});',
		returned : ''
	},

	'PointJS.brush.drawPoint' : {
		name     : 'Отрисовать точку',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор свойств >\
		{ >\
			`x : 10, // number, позиция по X > \
			`y : 50, // number, позиция по Y > \
			`fillColor : "red", // string, цвет точки > \
		}',
		example  : 'PointJS.brush.drawPoint({> `x : 20, y : 20, > `fillColor : "green" >});',
		returned : ''
	},

	'PointJS.brush.drawCircle' : {
		name     : 'Отрисовать окружность',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор свойств >\
		{ >\
			`x : 10, // number, позиция по X > \
			`y : 50, // number, позиция по Y > \
			`radius : 10, // number, радиус окружности > \
			`fillColor : "red", // string, цвет заливки > \
			`strokeColor : "white", // string, цвет линии обводки > \
			`strokeWidth : 2, // number, ширина линии обводки > \
		}',
		example  : 'PointJS.brush.drawCircle({> `x : 20, y : 20, > `radius : 10, > `fillColor : "green" >});',
		returned : ''
	},

	'PointJS.brush.drawLine' : {
		name     : 'Отрисовать линию',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор свойств >\
		{ >\
			`x1 : 10, // number, позиция начала по X > \
			`y1 : 50, // number, позиция начала по Y > \
			`x2 : 10, // number, позиция конца по X > \
			`y2 : 50, // number, позиция конца по Y > \
			`strokeColor : "white", // string, цвет линии > \
			`strokeWidth : 2, // number, ширина линии > \
		} > \
		Линия отсовывается в позиции x1, y1; > x2, y2 рассчитываются относительнo начальной точки',
		example  : 'PointJS.brush.drawLine({> `x1 : 20, y1 : 20, > `x2 : 50, y2 : 50, > `strokeColor : "green" >});',
		returned : ''
	},

	'PointJS.brush.drawLineA' : {
		name     : 'Отрисовать линию',
		type     : 'function',
		api      : '(obj);',
		note     : 'obj - object, набор свойств >\
		{ >\
			`x1 : 10, // number, позиция начала по X > \
			`y1 : 50, // number, позиция начала по Y > \
			`x2 : 10, // number, позиция конца по X > \
			`y2 : 50, // number, позиция конца по Y > \
			`strokeColor : "white", // string, цвет линии > \
			`strokeWidth : 2, // number, ширина линии > \
		} > \
		Линия отсовывается в абсолютных координатах x1, y1, x2, y2',
		example  : 'PointJS.brush.drawLineA({> `x1 : 20, y1 : 20, > `x2 : 100, y2 : 50, > `strokeColor : "green" >});',
		returned : ''
	},

	'PointJS.brush.getPixelColor' : {
		name     : 'Получить цвет пикселя',
		type     : 'function',
		api      : '(x, y);',
		note     : 'x - number, координата по X > y - number, координата по Y',
		example  : 'var color = PointJS.brush.getPixelColor(60, 10);',
		returned : 'string > Цвет пикселя в координатах x, y'
	},

	'PointJS.brush.setPixelColor' : {
		name     : 'Задать цвет пикселя',
		type     : 'function',
		api      : '(x, y, pixel);',
		note     : 'x - number, координата по X > y - number, координата по Y > \
														pixel - object, параметра пикселя: > \
														{>` r : 255, // красный >` g : 255, // зеленый >` b : 255, // синий >` a : 255 // Альфа-канал > } > \
														Все свойства являются необязательными',
		example  : 'PointJS.brush.setPixelColor(60, 10 { r : 100, g : 100 }); // установить пикселю значения красного и зеленого, остальные не будут затронуты',
		returned : ''
	},

	'PointJS.brush.onPixel' : {
		name     : 'Выполнить операцию с пикселем',
		type     : 'function',
		api      : '(x, y, function(pixel) {/*обработка*/});',
		note     : 'x - number, координата по X > y - number, координата по Y > \
														function(pixel) {/*обработка*/} - функция обработчик пикселя',
		example  : 'PointJS.brush.onPixel(100, 100, function(pixel) { >  \
														`// инвертирование цвета пикселя > \
														`pixel.r = 255 - pixel.r; > \
														`pixel.g = 255 - pixel.g; > \
														`pixel.b = 255 - pixel.b; > });',
		returned : ''
	},

	'PointJS.brush.onPixels' : {
		name     : 'Выполнить операцию с прямоугольником пикселей',
		type     : 'function',
		api      : '(x, y, w, h, function(pixel) {/*обработка*/});',
		note     : 'x - number, координата по X > y - number, координата по Y > w - number, ширина прямоугольника > h - number, высота прямоугольника > \
														function(pixel) {/*обработка*/} - функция обработчик пикселя > \
														Функция циклически применится ко всем пикселям, попадающим в прямоугольник > \
														В качестве аргумента принимает пиксель, изменяемый в цикле',
		example  : 'PointJS.brush.onPixels(100, 100, 50, 50, function(pixel) { >  \
														`// инвертирование цвета пикселя > \
														`pixel.r = 255 - pixel.r; > \
														`pixel.g = 255 - pixel.g; > \
														`pixel.b = 255 - pixel.b; > });',
		returned : ''
	},

	'PointJS.brush.onRawPixels' : {
		name     : 'Выполнить операцию с массивом пикселей',
		type     : 'function',
		api      : '(x, y, w, h, function(data, length) {/*обработка*/});',
		note     : 'x - number, координата по X > y - number, координата по Y > w - number, ширина прямоугольника > h - number, высота прямоугольника > \
														function(data, length) {/*обработка*/} - функция обработчик массива пикселей > \
														Функция передает обработчику массив пикселей контекста и его длину > \
														В качестве аргумента принимает массив data и числовое значение его длины - length',
		example  : 'PointJS.brush.onRawPixels(100, 100, 50, 50, function(data, length) { > \
														`// циклический проход по массиву пикселей > \
														`var i = 0; > \
														`for (; i < length; i++) { > \
															``data[i] = 255; // красный > \
															``data[i+1] = 255; // зеленый > \
															``data[i+2] = 255; // синий > \
															``data[i+3] = 255; // прозрачность  > \
															`} > \
														 });',
		returned : ''
	},





	 // audio
	'PointJS.audio.newAudio' : {
		name     : 'Новый аудио объект',
		type     : 'function',
		api      : '(file, volume);',
		note     : 'file - string, путь к файлу аудио, либо array - массив разных форматов файла > \
														volume - number, громкость [0-1]',
		example  : 'var music = PointJS.audio.newAudio("audio/music.mp3", 0.5); // загрузка файла формата mp3 > \
														var music = PointJS.audio.newAudio(["audio/music.mp3", "audio/music.ogg"], 0.5); // загрузка многоформатного аудио',
		returned : ' .Audio() '
	},



};




















var BaseObject = {
	'flip' : {
		type     : 'hidden',
	},

	'x' : {
		name     : 'Позиция по X',
		type     : 'property',
		api      : '',
		note     : 'Позиция объекта по оси X, начальная позиция отрисовки',
		example  : '',
		returned : 'number > Позиция по X'
	},

	'y' : {
		name     : 'Позиция по Y',
		type     : 'property',
		api      : '',
		note     : 'Позиция объекта по оси Y, начальная позиция отрисовки',
		example  : '',
		returned : 'number > Позиция по Y'
	},

	'w' : {
		name     : 'Ширина объекта',
		type     : 'property',
		api      : '',
		note     : 'Ширина объекта',
		example  : '',
		returned : 'number > Ширина объекта'
	},

	'h' : {
		name     : 'Высота объекта',
		type     : 'property',
		api      : '',
		note     : 'Высота объекта',
		example  : '',
		returned : 'number > Ширина объекта'
	},

	'fillColor' : {
		name     : 'Цвет заливки',
		type     : 'property',
		api      : '',
		note     : 'Цвет заливки объекта',
		example  : '',
		returned : 'string > Цвет'
	},

	'strokeColor' : {
		name     : 'Цвет обводки',
		type     : 'property',
		api      : '',
		note     : 'Цвет обводки (рамки) объекта',
		example  : '',
		returned : 'string > Цвет'
	},

	'strokeWidth' : {
		name     : 'Ширина линии обводки',
		type     : 'property',
		api      : '',
		note     : 'Ширина линии обводки (рамки) объекта',
		example  : '',
		returned : 'number > Ширина линии'
	},

	'angle' : {
		name     : 'Угол поворота объекта',
		type     : 'property',
		api      : '',
		note     : 'Угол поворота (наклона) объекта в градусах',
		example  : '',
		returned : 'number > Угол поворота'
	},

	'alpha' : {
		name     : 'Прозрачность объекта',
		type     : 'property',
		api      : '',
		note     : 'Прозрачность объекта. Задается в пределах от 0 (прозрачный) до 1 (непрозрачный)',
		example  : '',
		returned : 'number > Прозрачность'
	},

	'center' : {
		name     : 'Смещение центра объекта',
		type     : 'property',
		api      : ' - объект .point(0, 0) по умолчанию',
		note     : 'По умолчанию имеет координаты [0,0], то есть центр объекта. > \
		Можно сместить по x и / или y оси',
		example  : ' BaseObject.center.x = 5; // сместить на 5 пикселей вправо относильено центра объекта',
		returned : ' .point() > Смещение центра'
	},

	'visible' : {
		name     : 'Видимость объекта',
		type     : 'property',
		api      : '',
		note     : 'boolean > true - видимый, > false - невидимый',
		example  : '',
		returned : 'boolean > Видимость объекта'
	},

	'isArrIntersect' : {
		name     : 'Проверка столкновения с массивом объектов',
		type     : 'function',
		api      : '(arr)',
		note     : 'arr - array, массоив объектов > Функция проверяет динамические столкновения',
		example  : 'var intersect = obj.isArrIntersect( [obj1, obj2, ... objN] );',
		returned : 'boolean > true - столкновение с хотя бы одним объектом > false - нет ни одного столкновения'
	},

	'isArrInside' : {
		name     : 'Проверка полного вхождения объекта в какой-либо объект из массива',
		type     : 'function',
		api      : '(arr)',
		note     : 'arr - array, массоив объектов',
		example  : 'var inside = obj.isArrInside( [obj1, obj2, ... objN] );',
		returned : 'boolean > true - объект входит в один из объектов из массива > false - нет вхождений'
	},

	'getNearest' : {
		name     : 'Получить ближайший объект',
		type     : 'function',
		api      : '(arr)',
		note     : 'arr - array, массив объектов',
		example  : 'var nearest = obj.getNearest( [obj1, obj2, ... , objN] ); > nearest.drawDynamicBox(); // подсветить объект',
		returned : 'object > Ссылка на ближайший объект'
	},

	'setUserData' : {
		name     : 'Установка пользовательских свойств объекту',
		type     : 'function',
		api      : '(obj)',
		note     : 'obj - объект свойств, которые требуется инициализировать в объекте > \
		{ > `property : value, > `property2 : value2, > ```... > `propertyN : valueN > } > \
		Удобство фуннкции в том, что если вы не знаете каких-то системных, и случайно укажите их, \
		система их не перезапишет, используя только нестандартные свойства.',
		example  : 'obj.setUserData( { > `speed : 5, > `level : 1 > } );',
		returned : ''
	},

	'setFlip' : {
		name     : 'Установить объекту инверсию по осям',
		type     : 'function',
		api      : '(invX, invY)',
		note     : 'invX - boolean, инвертировать отрисовку по оси X > \
														invY - boolean, инвертировать отрисовку по оси Y > \
														Функция влияет на отрисовку изображений',
		example  : 'obj.setFlip(true, false); // или setFlip(1, 0)',
		returned : ''
	},

	'getDynamicBox' : {
		name     : 'Поучить набор точек динамического обрамления',
		type     : 'function',
		api      : '()',
		note     : 'Получение массива из .point() объектов, составляющих обрамление объекта Bounding-box',
		example  : 'var points = obj.getDynamicBox();',
		returned : 'array > Набор .point() объектов с координатами точек'
	},

	'isDynamicIntersect' : {
		name     : 'Пересечение динамической обалсти с другой динамической областью',
		type     : 'function',
		api      : '(dynamicArea)',
		note     : 'dynamicArea - array, набор .point() точек, составляющих область. > \
		Минимальное количество точек в массиве - 3. > \
		Примером такой области является .getDynamicBox() - Bounding-box объекта',
		example  : 'console.log(obj.isDynamicIntersect( obj.getDynamicBox() )',
		returned : 'boolean > true - области пересекаются > false - области не пересекаются'
	},

	'isDynamicInside' : {
		name     : 'Проверка вхождения одной области внутрь другой',
		type     : 'function',
		api      : '(dynamicArea)',
		note     : 'dynamicArea - array, набор .point() точек, составляющих область. > \
		Минимальное количество точек в массиве - 3. > \
		Примером такой области является .getDynamicBox() - Bounding-box объекта',
		example  : 'console.log(obj.isDynamicInside( obj.getDynamicBox() )',
		returned : 'boolean > true - область входит внутрь dynamicArea > false - область не входит в dynamicArea'
	},

	'drawDynamicBox' : {
		name     : 'Отрисовать Bounding-box объекта',
		type     : 'function',
		api      : '(strokeColor)',
		note     : 'strokeColor - цвет отрисовки dynamicArea, рисуются только грани.',
		example  : 'obj.drawDynamicBox();',
		returned : ''
	},

	'drawStaticBox' : {
		name     : 'Отрисовать статический Bounding-box объекта',
		type     : 'function',
		api      : '(strokeColor)',
		note     : 'strokeColor - цвет отрисовки dynamicArea, рисуются только грани.',
		example  : 'obj.drawStaticBox();',
		returned : ''
	},

	'isStaticIntersect' : {
		name     : 'Проверка пересечения объекта со StaticBox',
		type     : 'function',
		api      : '(staticBox)',
		note     : 'staticBox - Прямоугольник, обрамляющий все не вращающиеся объекты',
		example  : 'obj.isStaticIntersect( obj.getStaticBox() );',
		returned : ''
	},

	'getStaticBox' : {
		name     : 'Получение staticBox объекта. статический Bounding-box',
		type     : 'function',
		api      : '()',
		note     : 'Отличается от dynamicArea тем, что его использование целесообразно там, где объекты не \
		подразумевается вращать. > \
		!! staticBox нельзя передавать арзументом в функции, принимающие dynamicArea !!',
		example  : 'var staticBox = obj.getStaticBox();',
		returned : 'object > x - Позиция по X > y - Позиция по Y > w : Ширина прямоугольника > h : Высота прямоугольника'
	},

	'setAlpha' : {
		name     : 'Установить прозрачность',
		type     : 'function',
		api      : '(alpha)',
		note     : 'alpha - number, степень прозрачности. > 0 - прозрачный, 1 - непрозрачный',
		example  : 'obj.setAlpha(0.5);',
		returned : ''
	},

	'getAlpha' : {
		name     : 'Получить прозрачность',
		type     : 'function',
		api      : '()',
		note     : '',
		example  : 'obj.getAlpha(0.5);',
		returned : 'number > Степень прозрачности'
	},

	'rotate' : {
		name     : 'Повернуть объект в направлении точки или вектора',
		type     : 'function',
		api      : '(point || vector2D)',
		note     : 'point - .point(), точка в пространстве > vector2D - .v2d(), вектор',
		example  : '// Повернуть объект в сторону другого объекта > obj.rotate( obj.getPosition() );',
		returned : 'number > Степень прозрачности'
	},

	'setCenter' : {
		name     : 'Сместить центр объекта',
		type     : 'function',
		api      : '(vector2D)',
		note     : 'vector2D - .v2d(), вектор смещения',
		example  : 'obj.setCenter( .v2d(10, 0) ); // сместить центр объекта на 10 пикселей по X (вправо)',
		returned : ''
	},

	'getCenter' : {
		name     : 'Получить смещенный центр объекта',
		type     : 'function',
		api      : '()',
		note     : 'Вернет центр объекта, по умолчанию .point(0, 0)',
		example  : 'var point = obj.getCenter( .v2d(10, 0) );',
		returned : ' .point() > Центр объекта'
	},

	'move' : {
		name     : 'Двигать объект в направлении',
		type     : 'function',
		api      : '(vector2D)',
		note     : 'vector2D - .v2d(), направление движения',
		example  : 'obj.move( .v2d(1, 0) ); // двигать вправо на 1 пиксель',
		returned : ''
	},

	'scale' : {
		name     : 'Увеличиывть объект',
		type     : 'function',
		api      : '(size)',
		note     : 'size - .w2h(), оси увеличения > положительные значение - увеличение > отрицательные - уменьшение > 0 - не изменять размер',
		example  : 'obj.scale( .w2h(1, 1) ); // увеличивать пропорционально на 1 пиксель по ширине и 1 по высоте',
		returned : ''
	},

	'scaleC' : {
		name     : 'Увеличиывть объект относильено центра',
		type     : 'function',
		api      : '(size)',
		note     : 'size - .w2h(), оси увеличения > положительные значение - увеличение > отрицательные - уменьшение > 0 - не изменять размер > \
		При масштабировании центр объекта сохраняется',
		example  : 'obj.scaleC( .w2h(1, 1) ); // увеличивать пропорционально на 1 пиксель по ширине и 1 по высоте',
		returned : ''
	},

	'getPosition' : {
		name     : 'Получение позиции объекта',
		type     : 'function',
		api      : '([format])',
		note     : 'format - number, тип позиции, которую требуется получить. > \
		0 или отсутствует - координаты верхнего левого угла > \
		1 - позиция с учетом смещенного центра объекта (рекомендуется) > \
		2 - позиция центра фигуры (с учетом вращения). > \
		Рекомендуется использовать format = 1 для получения центра объекта с учетом смещения и поворота.',
		example  : 'var point = obj.getPosition( 1 );',
		returned : ' .point() > x : Позиция по X > y - Позиция по Y'
	},

	'setPosition' : {
		name     : 'Установить объект в позицию',
		type     : 'function',
		api      : '(point || vector2D)',
		note     : 'point - .point(), точка в пространстве > vector2D - .v2d(), вектор',
		example  : 'obj.setPosition( .point(100, 100) ); // Поместить в позицию 100 по X и 100 по Y',
		returned : ''
	},

	'setPositionC' : {
		name     : 'Установить объект в позицию c учетом центра',
		type     : 'function',
		api      : '(point || vector2D)',
		note     : 'point - .point(), точка в пространстве > vector2D - .v2d(), вектор  > \
		Функция установит объект с учетом его смещенного центра и поворота.',
		example  : 'obj.setPositionC( .point(100, 100) ); // Поместить в позицию 100 по X и 100 по Y',
		returned : ''
	},

	'getSize' : {
		name     : 'Получить размер объекта',
		type     : 'function',
		api      : '()',
		note     : '',
		example  : 'var size = obj.getSize();',
		returned : ' .size() > w - Ширина объекта > h - Высота объекта'
	},

	'setSize' : {
		name     : 'Задать размер объекта',
		type     : 'function',
		api      : '(size)',
		note     : 'size - .w2h() - новый размер объекта',
		example  : 'obj.setSize( .w2h(10, 50) );',
		returned : ''
	},

	'setSizeC' : {
		name     : 'Задать размер объекта с учетом центра',
		type     : 'function',
		api      : '(size)',
		note     : 'size - .w2h() - новый размер объекта > \
		При задании объекту нового размера его центр сохраняется',
		example  : 'obj.setSizeC( .w2h(10, 50) );',
		returned : ''
	},

	'turn' : {
		name     : 'Вращать объект',
		type     : 'function',
		api      : '(angle)',
		note     : 'angle - number, значение поворота, которое будет прибавлено к текущему повороту > \
		Положительное значение вращает по часовой стрелке, > \
		Отрицательное значение вращает против часовой стрекли',
		example  : 'obj.turn( 1 );  // вращать на 1 градус по часовой стрелке',
		returned : ''
	},

	'moveAngle' : {
		name     : 'Двигать объект в соответствии с направлением',
		type     : 'function',
		api      : '(speed)',
		note     : 'speed - number, скорость движения. > \
		Функция учитывает направление объекта.',
		example  : 'obj.moveAngle( 1 );  // Двигать в направлении поворота на скорости 1 пиксель',
		returned : ''
	},

	'circling' : {
		name     : 'Двигать объект по окружности вокруг точки',
		type     : 'function',
		api      : '(point, radius, speed)',
		note     : 'point - .point(), центр вращения > \
		radius - number, радиус окружности > \
		speed - number, скорость движения > \
		Функция двигает объект по окружности вокруг точки',
		example  : 'obj.circling( mouse.getMousePositionA(), 10, 1 );  // Двигать объект вокруг курсора по радиусу 10 и скорости 1',
		returned : ''
	},

	'circlingC' : {
		name     : 'Двигать объект по окружности вокруг точки',
		type     : 'function',
		api      : '(point, radius, speed)',
		note     : 'point - .point(), центр вращения > \
		radius - number, радиус окружности > \
		speed - number, скорость движения > \
		Функция двигает объект по окружности вокруг точки > \
		Функция учитывает центр объекта',
		example  : 'obj.circlingC( mouse.getMousePositionA(), 10, 1 );  // Двигать объект вокруг курсора по радиусу 10 и скорости 1',
		returned : ''
	},

	'motion' : {
		name     : 'Двигать объект по элипсоиду вокруг точки',
		type     : 'function',
		api      : '(point, size, speed)',
		note     : 'point - .point(), центр вращения > \
		size - .size(), ширина/высота элипсоида > \
		speed - number, скорость движения > \
		Функция двигает объект по элипсоиду вокруг точки',
		example  : 'obj.motion( mouse.getMousePositionA(), size(50, 10), 1 );  // Двигать объект вокруг курсора по радиусу 50x10 и скорости 1',
		returned : ''
	},

	'motionC' : {
		name     : 'Двигать объект по элипсоиду вокруг точки',
		type     : 'function',
		api      : '(point, size, speed)',
		note     : 'point - .point(), центр вращения > \
		size - .size(), ширина/высота элипсоида > \
		speed - number, скорость движения > \
		Функция двигает объект по элипсоиду вокруг точки > \
		Функция учитывает центр объекта',
		example  : 'obj.motionC( mouse.getMousePositionA(), size(50, 10), 1 );  // Двигать объект вокруг курсора по радиусу 50x10 и скорости 1',
		returned : ''
	},

	'getAngle' : {
		name     : 'Поучить угол вращения объекта в градусах',
		type     : 'function',
		api      : '()',
		note     : '',
		example  : 'obj.getAngle();',
		returned : 'number > Угол в градусах'
	},

	'setAngle' : {
		name     : 'Установить угол вращения объекта в градусах',
		type     : 'function',
		api      : '(angle)',
		note     : 'angle - number, угол в градусах. > В отличии от команды turn(), эта команда не прибавляет угол, а перезаписывает его.',
		example  : 'obj.setAngle(45);',
		returned : ''
	},

	'moveTime' : {
		name     : 'Двигать объект к точке за указанные время',
		type     : 'function',
		api      : '(point, time)',
		note     : 'point - ,point(), точка > time - number, время, требуемое для движения',
		example  : 'obj.moveTime(mouse.getMousePositionA(), 5);',
		returned : ''
	},

	'moveTimeC' : {
		name     : 'Двигать объект к точке за указанные время',
		type     : 'function',
		api      : '(point, time)',
		note     : 'point - ,point(), точка > time - number, время, требуемое для движения > \
														Функция учитывает центр объекта',
		example  : 'obj.moveTimeC(mouse.getMousePositionA(), 5);',
		returned : ''
	},

	'getDistance' : {
		name     : 'Поучить расстояние до точки',
		type     : 'function',
		api      : '(point)',
		note     : 'point - .point(), точка, до которой нужно рассчитать расстояние',
		example  : 'obj.getDistance( obj2.getPosition(2) ); // Получить расстояние до объектa obj2',
		returned : ''
	},

	'getDistanceC' : {
		name     : 'Поучить расстояние до точки c учетом центра',
		type     : 'function',
		api      : '(point)',
		note     : 'point - .point(), точка, до которой нужно рассчитать расстояние > \
		Функция учитывает центр объекта и отсчет начинается от него.',
		example  : 'obj.getDistanceC( obj2.getPosition(1) ); // Получить расстояние до объектa obj2',
		returned : ''
	},

	'setVisible' : {
		name     : 'Установить видимость объекту',
		type     : 'function',
		api      : '(bool)',
		note     : 'bool - boolean > true - видимый объект > false - невидимый > \
		Невидимые объекты так же реагируют на столкновения, имеют угол вращения и т.д. > \
		Невидимый объект просто не отображается.',
		example  : 'obj.setVisible( false ); // Сделать объект невидимым',
		returned : ''
	},

	'isVisible' : {
		name     : 'Проверить флаг видимости объекта',
		type     : 'function',
		api      : '()',
		note     : '',
		example  : 'var visible = obj.isVisible();',
		returned : 'boolean > true - объект видимый > false - объект не видим'
	},

	'isInCamera' : {
		name     : 'Проверить видит ли объект камера (игрок)',
		type     : 'function',
		api      : '()',
		note     : '',
		example  : 'var visible = obj.isInCamera();',
		returned : 'boolean > true - объект в пределах видимости > false - объект за пределами, камера его не видит'
	},

	'draw' : {
		name     : 'Отрисовать объект',
		type     : 'function',
		api      : '()',
		note     : 'Отрисовывает объект на сцене. > Не требуется, если установлен флаг AutoDraw',
		example  : 'obj.draw();',
		returned : ''
	},



};














var RectObject = {
	'draw' : {
		name     : 'Отрисовать прямоугольник',
		type     : 'function',
		api      : '()',
		note     : 'Отрисовывает объект на сцене. > Не требуется, если установлен флаг AutoDraw',
		example  : 'obj.draw();',
		returned : ''
	},

};
















var ImageObject = {
	'draw' : {
		name     : 'Отрисовать изображение',
		type     : 'function',
		api      : '()',
		note     : 'Отрисовывает объект на сцене. > Не требуется, если установлен флаг AutoDraw',
		example  : 'obj.draw();',
		returned : ''
	},

	'simpleDraw' : {
		name     : 'Отрисовать копию изображения в позиции',
		type     : 'function',
		api      : '(point)',
		note     : 'point - .point(), позиция отрисовки',
		example  : 'obj.simpleDraw( .point(100, 100) );',
		returned : ''
	},

	'setImage' : {
		name     : 'Установить объекту новое изображение',
		type     : 'function',
		api      : '(file)',
		note     : 'file - string, путь к файлу изображения',
		example  : 'obj.setImage( "images/image.png" );',
		returned : ''
	},

	'getImage' : {
		name     : 'Получить ссылку на изображение',
		type     : 'function',
		api      : '()',
		note     : 'Вернет ссылку на изображение',
		example  : 'var img = obj.getImage(); > obj2.setImage(img);',
		returned : 'string > Путь к файлу изображения'
	},

	'loaded' : {
		name     : 'Статус загрузки',
		type     : 'property',
		api      : '',
		note     : 'Статус загруженности изображения',
		example  : '',
		returned : 'boolean > true - изображение загружено > false - изображение не загружено'
	},

	'file' : {
		name     : 'Файл изображения',
		type     : 'property',
		api      : '',
		note     : 'Путь к файлу изображения',
		example  : '',
		returned : ''
	},

};


















var AnimationObject = {
	'step' : {
		type     : 'hidden',
	},

	'difStep' : {
		type     : 'hidden',
	},

	'anim' : {
		type     : 'hidden',
	},

	'frame' : {
		name     : 'Текущий кадр',
		type     : 'property',
		api      : '',
		note     : 'Текущий кадр в проигрываемой анимации',
		example  : '',
		returned : ''
	},

	'getAnimation' : {
		name     : 'Получить анимацию объекта',
		type     : 'function',
		api      : '()',
		note     : 'Вернет анимацию объекта',
		example  : 'var anim = obj.getAnimation(); > obj2.setAnimation(anim);',
		returned : ' .Animation() > Объект с параметрами анимации'
	},

	'setAnimation' : {
		name     : 'Присвоить анимацию объекту',
		type     : 'function',
		api      : '(anim)',
		note     : 'anim -  .Animation(), объект с параметрами анимации',
		example  : 'var anim = obj.setAnimation(); > obj2.setAnimation(anim);',
		returned : ''
	},

	'draw' : {
		name     : 'Отрисовать всю анимацию',
		type     : 'function',
		api      : '()',
		note     : 'Отрисовка всех кадров анимации. > Для задания замедления анимации используется параметр delay > \
														delay - number, замедление анимации',
		example  : 'obj.draw();',
		returned : ''
	},

	'drawFrame' : {
		name     : 'Отрисовать один кадр',
		type     : 'function',
		api      : '(frame)',
		note     : 'frame - number, кадр, который требуется отрисивать',
		example  : 'obj.drawFrame();',
		returned : ''
	},

	'drawFrames' : {
		name     : 'Отрисовать последовательность кадров',
		type     : 'function',
		api      : '(frame_start, frame_end)',
		note     : 'frame_start - number, начальный кадр > frame_end - number, конечный кадр',
		example  : 'obj.drawFrames(1, 5); // воспроизведение анимации с 1 по 5 кадр',
		returned : ''
	},





};

















var CircleObject = {
	'scale' : {
		name     : 'Увеличивать радиус окружности',
		type     : 'function',
		api      : '(num)',
		note     : 'num - number, количество пикселей, на которое радиус увеличивается > Положительное число увеличивает > \
		Отрицательное число уменьшает',
		example  : 'obj.scale(2);',
		returned : ''
	},

	'scaleC' : {
		name     : 'Увеличивать радиус окружности с учетом центра',
		type     : 'function',
		api      : '(num)',
		note     : 'num - number, количество пикселей, на которое радиус увеличивается > Положительное число увеличивает > \
		Отрицательное число уменьшает > При увеличении радиуса окружности центр остается на месте',
		example  : 'obj.scaleC(2);',
		returned : ''
	},

	'getRadius' : {
		name     : 'Поучить радиус окружности',
		type     : 'function',
		api      : '()',
		note     : '',
		example  : 'var radius = obj.getRadius();',
		returned : 'number > Радиус окружности'
	},

	'setRadius' : {
		name     : 'Установить радиус окружности',
		type     : 'function',
		api      : '(radius)',
		note     : 'radius number, Радиус окружности',
		example  : 'obj.setRadius(10);',
		returned : ''
	},

	'radius' : {
		name     : 'Pадиус окружности',
		type     : 'property',
		api      : '',
		note     : 'Радиус окружности',
		example  : '',
		returned : ''
	},



};





















var Image = {
	'file' : {
		type     : 'hidden',
	},

	'loaded' : {
		name     : 'Состояние загруженности изображения',
		type     : 'property',
		api      : '',
		note     : 'true - Изображение загружено > false - изображение не загружено',
		example  : '',
		returned : ''
	},

	'getTile' : {
		name     : 'Извлечь часть изображения в тайл',
		type     : 'function',
		api      : '(x, y, w, h)',
		note     : 'x - координата X > y - координата Y > w - ширина > h - высота > \
														Будет извлечен прямоугольник из изображения',
		example  : 'obj.getTile( 10, 10, 50, 50 );',
 	returned : ' .tile() > Фрагмент изображения. Тайл'
	},

	'getAnimation' : {
		name     : 'Извлечь последовательность фреймов (кадров, тайлов) для анимирования',
		type     : 'function',
		api      : '(x, y, w, h, count)',
		note     : 'x - координата X > y - координата Y > w - ширина > h - высота > \
														count - количество кадров по ГОРИЗОНТАЛИ > \
														Будет извлечена последовательность кадров для анимации',
		example  : 'obj.getAnimation( 10, 10, 50, 50, 5 );',
		returned : ' .Animation() > Анимации'
	},

};


















var Audio = {
	'vol' : {
		type     : 'hidden',
	},

	'audio' : {
		type     : 'hidden',
	},

	'nextPlay' : {
		type     : 'hidden',
	},

	'playing' : {
		name     : 'Состояние воспроизведения',
		type     : 'property',
		api      : '',
		note     : 'true - Музыка воспроизводится > false - Музыка не воспроизводится',
		example  : '',
		returned : ''
	},

	'loaded' : {
		name     : 'Состояние загруженности аудио',
		type     : 'property',
		api      : '',
		note     : 'true - Аудиофайл загружен > false - Аудиофайл не загружен',
		example  : '',
		returned : ''
	},

	'play' : {
		name     : 'Воспроизвести аудио',
		type     : 'function',
		api      : '([volume])',
		note     : 'volume - number, громкость > Если воспроизведение остановили функцией pause(), проигрывание продолжится с места остановки',
		example  : 'Audio.play();',
		returned : ''
	},

	'replay' : {
		name     : 'Воспроизвести аудио сначала',
		type     : 'function',
		api      : '([volume])',
		note     : 'volume - number, громкость > Если воспроизведение остановили функцией pause(), проигрывание все равно начнется сначала > \
														Если на момент вызова функции файл воспроизводится, воспроизведение начнется сначала',
		example  : 'Audio.replay();',
		returned : ''
	},

	'stop' : {
		name     : 'Полная остановка воспроизведения',
		type     : 'function',
		api      : '()',
		note     : 'Останавливает воспроизведение аудио',
		example  : 'Audio.stop();',
		returned : ''
	},

	'pause' : {
		name     : 'Приостановка воспроизведения',
		type     : 'function',
		api      : '()',
		note     : 'Приостанавливает воспроизведение аудио > Продолжить воспроизведение можно функцией play()',
		example  : 'Audio.pause();',
		returned : ''
	},

	'setNextPlay' : {
		name     : 'Установить следующий файл воспроизведения',
		type     : 'function',
		api      : '(audio)',
		note     : 'audio - .Audio(), аудио, которое будет воспроизведено сразу после того, как закончится текущий файл.',
		example  : 'audio1.setNextPlay( audio2 );',
		returned : ''
	},

	'setVolume' : {
		name     : 'Установить громкость воспроизведения',
		type     : 'function',
		api      : '(volume)',
		note     : 'volume - number, громкость воспроизведения > 0 - полная тишина, 1 - полная громкость',
		example  : 'audio1.setVolume( 0.5 ); // Половина громкости',
		returned : ''
	},

	'getVolume' : {
		name     : 'Получить громкость воспроизведения',
		type     : 'function',
		api      : '()',
		note     : '',
		example  : 'var volume = audio1.getVolume(); // 0.5',
		returned : 'number > Громкость воспроизведения'
	},




};













var EllipsObject = {
	'draw' : {
		name     : 'Отрисовать элипс',
		type     : 'function',
		api      : '()',
		note     : 'Отрисовывает объект на сцене. > Не требуется, если установлен флаг AutoDraw',
		example  : 'obj.draw();',
		returned : ''
	},
};















var PolygonObject = {
	'dX' : {
		type     : 'hidden',
	},

	'dY' : {
		type     : 'hidden',
	},

	'points' : {
		type     : 'hidden',
	},

	'pointColor' : {
		name     : 'Цвет вершин для отрисовки',
		type     : 'property',
		api      : '',
		note     : 'Цвет вершин',
		example  : '',
		returned : ''
	},

	'addPoint' : {
		name     : 'Добавить новую вершину в полигон',
		type     : 'function',
		api      : '(point)',
		note     : 'point - .point(), вершина для добавления > Координаты будут отсчитаны относительно позиции объекта',
		example  : 'PolygonObject.addPoint( .point(10, 10) ); // добавить точку в объект',
		returned : ''
	},

	'delPoint' : {
		name     : 'Удалить вершину из полигона',
		type     : 'function',
		api      : '(N)',
		note     : 'N - порядковый номер точки, которую требуется удалить. > Отсчет начинается с нуля.',
		example  : 'PolygonObject.delPoint( 2 ); // Удалить вторую точку из полигона',
		returned : ''
	},

	'clearPoints' : {
		name     : 'Удалить все вершины',
		type     : 'function',
		api      : '()',
		note     : 'Очистка всех вершин',
		example  : 'PolygonObject.clearPoints(); // Удалить все вершины',
		returned : ''
	},

	'getPoints' : {
		name     : 'Получить все вершины',
		type     : 'function',
		api      : '()',
		note     : 'Получить все вершины полигона',
		example  : 'PolygonObject.getPoints();',
		returned : 'array > Список .point() объектов с координатами точек'
	},

	'getCount' : {
		name     : 'Получить количество вершин в полигоне',
		type     : 'function',
		api      : '()',
		note     : 'Получить количество всех вершин',
		example  : 'PolygonObject.getCount();',
		returned : 'number > Количество вершин'
	},

	'getPoint' : {
		name     : 'Обратиться к точке',
		type     : 'function',
		api      : '(N)',
		note     : 'Обратиться к точке с номером N',
		example  : 'PolygonObject.getPoint(2); // обратиться к точке с порядковым номером 2',
		returned : ' .point() > Координаты точки'
	},







};





















var Mesh = {
	'x' : {
		name     : 'Смещение группы по X',
		type     : 'property',
		api      : '',
		note     : '',
		example  : '',
		returned : ''
	},

	'y' : {
		name     : 'Смещение группы по Y',
		type     : 'property',
		api      : '',
		note     : '',
		example  : '',
		returned : ''
	},

	'count' : {
		name     : 'Количество объектов в группе',
		type     : 'hidden',
		api      : '',
		note     : '',
		example  : '',
		returned : ''
	},

	'getCount' : {
		name     : 'Количество объектов в группе',
		type     : 'function',
		api      : '',
		note     : '',
		example  : '',
		returned : 'number > Количество объектов'
	},

	'objs' : {
		name     : 'Массив объектов',
		type     : 'hidden',
		api      : '',
		note     : '',
		example  : '',
		returned : 'array > Массив объектов'
	},

	'add' : {
		name     : 'Добавить объект в группу',
		type     : 'function',
		api      : '(obj)',
		note     : 'obj - Object, любой объект, наследующий .BaseObject(), который требуется добавить в Mesh',
		example  : 'Mesh.add( .BaseObject() );',
		returned : ''
	},

	'del' : {
		name     : 'Удалить объект из группы',
		type     : 'function',
		api      : '(obj)',
		note     : 'obj - Object, любой объект, наследующий .BaseObject(), который находится в .Mesh()',
		example  : 'Mesh.del( .BaseObject() );',
		returned : ''
	},

	'turn' : {
		name     : 'Вращать группу объектов',
		type     : 'function',
		api      : '(angle)',
		note     : 'angle - number, угол вращения',
		example  : 'Mesh.turn( 3 ); // вращение на скорости 3 градуса за итерацию',
		returned : ''
	},

	'setAngle' : {
		name     : 'Установить угол поворота группе объектов',
		type     : 'function',
		api      : '(angle)',
		note     : 'angle - number, угол вращения',
		example  : 'Mesh.setAngle( 3 ); // вращение на скорости 3 градуса за итерацию',
		returned : ''
	},




};


















var apiNotes = {
	'BaseObject' : 'Базовый объект',
	'RectObject' : 'Объект "Прямоугольник"',
	'CircleObject' : 'Объект "Окружность"',
	'EllipsObject' : 'Объект "элипс"',
	'ImageObject' : 'Объект "изображение"',
	'AnimationObject' : 'Объект "анимация"',
	'Mesh' : 'Объект "Меш"',
	'Audio' : 'Объект "Audio"',
};






